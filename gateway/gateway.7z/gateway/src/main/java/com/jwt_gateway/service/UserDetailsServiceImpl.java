package com.jwt_gateway.service;

//import com.exam.model.User;
//import com.exam.repo.UserRepository;
import com.jwt_gateway.entity.UserData;
import com.jwt_gateway.repository.UserReposs;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsServiceImpl
//        implements UserDetailsService
{
//
//    @Autowired
//    private UserReposs userRepository;
//
//    @Override
//    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//
//        UserData user = this.userRepository.findByUsername(username);
//        if (user == null) {
//            System.out.println("User not found");
//            return "No user found !!";
////            throw new UsernameNotFoundException("No user found !!");
//        }
//
//        return user;
//    }
}
